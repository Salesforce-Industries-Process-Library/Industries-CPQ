# Digital Commerce LWC

## How to extend Digital Commerce LWC Component

```javascript
import dcCatalog from "vlocity_cmt/dcCatalog";

class customDCCatalog extends dcCatalog {
  // your code goes here
  // override methods here
}
```

HTML templates for all the LWC's can be found in this folder.

## How to download and use Newport Design System

1. Clone the project with git clone https://github.com/vlocityinc/newport-design-system.git
2. Change it to the newport-design-system folder using cd newport-design-system
3. Switch to the right branch for your version of the package, for example, git checkout cmt-107.1
4. Run npm install
5. Run npm start to launch storybook
6. Goto UI/components/digitalcommerce
7. Modify styles as per requirement.
8. Compile your CSS changes using npm run build && npm run dist
9. Goto dist folder and upload newport-design-system.zip file into your org static resources.
10. Name the static resource file, say newport_dc
11. Select cache Control as public and click on the Save button.
12. Now open your uploaded static resource newport_dc file again and do right click and copy the link address option.
13. Now goto setup and search for Custom Settings.
14. Search for UISettings and click on manage.
15. Click on the new button and create new setting by giving the name as newportZipUrl
16. Give the key as newport_dc
17. Paste the copied URL into the value input text box. Trim the prefix and '?' at end. So it looks like `/resource/1586776716000/newport_dc`
18. Now refresh your application to see updated styles.
