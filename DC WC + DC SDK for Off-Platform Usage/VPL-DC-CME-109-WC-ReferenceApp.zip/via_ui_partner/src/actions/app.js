/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/

export const UPDATE_PAGE = 'UPDATE_PAGE';
export const UPDATE_OFFLINE = 'UPDATE_OFFLINE';
export const UPDATE_DRAWER_STATE = 'UPDATE_DRAWER_STATE';
export const OPEN_SNACKBAR = 'OPEN_SNACKBAR';
export const CLOSE_SNACKBAR = 'CLOSE_SNACKBAR';

export const navigate = (path) => (dispatch) => {
  // Extract the page name from path.
  const page = path === '/' ? 'home' : path.slice(1);

  // Any other info you might want to extract from the path (like page type),
  // you can do here
  dispatch(loadPage(page));

  // Close the drawer - in case the *path* change came from a link in the drawer.
  dispatch(updateDrawerState(false));
};

const loadPage = (page) => (dispatch) => {
  let cur_page = page?page.split("/")[0] : '';
  switch(cur_page) {
    case 'home':
      import('../components/reference/reference-home-page/reference-home-page.js').then((module) => {
      import ('../components/reference/reference-loader/reference-loader.js');
      import ('../components/reference/reference-catalog/reference-catalog.js');
      import ('../components/reference/reference-product-list/reference-product-list.js');
      import('../components/reference/reference-sub-catalog/reference-sub-catalog.js');
      import ('../components/reference/reference-list-view-price/reference-list-view-price.js');
      import ('../components/reference/reference-grid-view/reference-grid-view.js');
      import('../components/reference/reference-checkout/reference-checkout.js');
      import('../components/reference/reference-selection-page/reference-selection-page.js');
      import('../components/reference/reference-shopping-cart/reference-shopping-cart.js');
      });
      break;
    case 'shoppingcart':
      import('../components/reference/reference-shopping-cart/reference-shopping-cart.js').then((module) => {
        import ('../components/reference/reference-shopping-nested-product/reference-shopping-nested-product.js');
        import ('../components/reference/reference-shopping-product-details/reference-shopping-product-details.js');
        import ('../components/reference/reference-totalbar/reference-totalbar.js');
        import ('../components/reference/reference-shopping-select-number/reference-shopping-select-number.js');
      });
      break;
    case 'config':
      import('../components/reference/reference-selection-page/reference-selection-page.js').then((module) => {
        import ("../components/reference/reference-product-configurations/reference-product-configurations.js");
        import ('../components/reference/reference-loader/reference-loader.js');
      });
      break;
      case 'checkout':
          import('../components/reference/reference-checkout/reference-checkout.js').then((module) => {
          import ('../components/reference/reference-loader/reference-loader.js');
        });
        break;
      case 'account':
          import('../components/reference/reference-my-account/reference-my-account.js').then((module) => {
          import ('../components/reference/reference-loader/reference-loader.js');
        });
        break;    
    default:
      cur_page = 'view404';
      import('../components/my-view404.js');
  }

  dispatch(updatePage(page));
};

const updatePage = (page) => {
  return {
    type: UPDATE_PAGE,
    page
  };
};

let snackbarTimer;

export const showSnackbar = () => (dispatch) => {
  dispatch({
    type: OPEN_SNACKBAR
  });
  window.clearTimeout(snackbarTimer);
  snackbarTimer = window.setTimeout(() =>
    dispatch({ type: CLOSE_SNACKBAR }), 3000);
};

export const updateOffline = (offline) => (dispatch, getState) => {
  // Show the snackbar only if offline status changes.
  if (offline !== getState().app.offline) {
    dispatch(showSnackbar());
  }
  dispatch({
    type: UPDATE_OFFLINE,
    offline
  });
};

export const updateDrawerState = (opened) => {
  return {
    type: UPDATE_DRAWER_STATE,
    opened
  };
};
