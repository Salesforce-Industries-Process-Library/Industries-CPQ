import { html, render } from "lit-html";

// These are the shared styles needed by this element.
import { SharedStyles } from "./shared-styles.js";

class MyView6 extends HTMLElement {

  constructor() {
    super();
    this.render();
  }

  template(scope) {
    let dataTableTemplate =  html``;
    return dataTableTemplate;
  }
  render() {
    this.template && render(this.template(this), this);
  }
}

window.customElements.define("home-page", MyView6);
