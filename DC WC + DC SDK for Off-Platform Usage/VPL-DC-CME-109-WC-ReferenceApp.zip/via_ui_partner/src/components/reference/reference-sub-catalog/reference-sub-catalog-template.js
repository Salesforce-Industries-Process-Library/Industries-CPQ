import { LitElement, html } from "lit-element";
let active = false;

let subCatalogTemplate = function prepareTemplate(ele) {
  let subCatlogList = ele.subCatalogs && ele.subCatalogs.data || [];
  let title = ele.category;
  let style = html`
    
  `;
  let template = html`
  `;
  return template;
};

export default subCatalogTemplate;
