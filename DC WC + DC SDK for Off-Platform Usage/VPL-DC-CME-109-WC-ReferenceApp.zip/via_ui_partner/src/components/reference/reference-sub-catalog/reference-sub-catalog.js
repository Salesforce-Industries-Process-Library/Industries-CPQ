import { LitElement, html } from "lit-element";
import VlocitySubCatalog from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-child-catalog/vlocity-dc-child-catalog.js";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils.js";
import referenceSubCatalogPageTemplate from "./reference-sub-catalog-template.js";

export default class ReferenceSubCatalogPage extends VlocitySubCatalog {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceSubCatalogPageTemplate;
    }
    render() {
      return this.template(this);
    }
}

customElements.define("reference-sub-catalog", ReferenceSubCatalogPage);