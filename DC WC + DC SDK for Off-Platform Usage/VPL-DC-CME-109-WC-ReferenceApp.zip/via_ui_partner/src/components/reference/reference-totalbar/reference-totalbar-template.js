import { LitElement, html } from "lit-element";

let vlocityTotalbarTemplate = function prepareTemplate(ele) {
  let vlocityTotalbar = ele.totalbar;
  let style = html`
    <style>
      .reference-total-bar {
        width: 90%;
        position: fixed;
        bottom: 15px;
        padding: 10px;
        background: #fff;
        border-top: 1px solid #ccc;
      }
      .total-items-in-cart {
        font-size: 13px;
        color: #AEB2B3;
        font-weight: normal;
        margin-left: -64px;
      }
      .total-section {
        margin: auto;
        display: table;
      }
      .total-section .price {
        font-weight: bold;
        font-size: 14px;
        margin-right: 10px;
        max-width: 100px;
      }
      .total-section .checkout-btn {
        color: #fff;
        background-color: #008ab3;
        text-align: center;
        font-size: 13px;
        display: table-cell;
        padding: 5px 90px;
        border-radius: 13px;
        cursor: pointer;
        text-decoration: none;
      }
      .total-section .checkout-btn.disable {
        pointer-events: none;
        background-color: #ccc;
        color: #ccc;
      }
      .total-section .checkout-btn.empty {
        opacity: 0;
      }
      @media only screen and (max-width: 320px) {
        .reference-total-bar {
          bottom: 2px;
          width: auto;
        }
        .total-section .checkout-btn {
          padding: 5px 60px;
        }
      }
    </style>
  `;
  let template = html`
    ${style}
    <div class="reference-total-bar">
      <div class="total-section">
        <div class="price">
          <div class="total-items-in-cart">Items (${ele.totalItems})</div>
        </div>
        <div class="checkout-btn empty"></div>
      </div>
      <div class="total-section">
        <div class="price">Total: $${ele.activatePromo?(ele.dueToday-(ele.dueToday*0.1)):ele.dueToday}</div>
        ${ele.disableBtn ? html`
          <div class="checkout-btn disable">${ele.btnText}</div>
        `:html`
          <a class="checkout-btn" href="checkout">${ele.btnText}</a>
        `}
      </div>
    </div>
  `;
  return template;
};

export default vlocityTotalbarTemplate;
