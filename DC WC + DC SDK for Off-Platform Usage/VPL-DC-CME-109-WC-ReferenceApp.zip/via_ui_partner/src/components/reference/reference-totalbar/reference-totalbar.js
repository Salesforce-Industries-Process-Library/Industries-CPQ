import { LitElement, html } from "lit-element";
import vlocityTotalbarTemplate from "./reference-totalbar-template";
import Vlocitytotalbar from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-totalbar/vlocity-dc-totalbar";

class ReferenceTotalBar extends Vlocitytotalbar {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = vlocityTotalbarTemplate;
    }
    static get properties() {
      return {
        disableBtn: Boolean,
        totalItems: Number,
        activatePromo: Boolean
      };
    }
    render() {
      return this.template(this);
    }
}

customElements.define("reference-total-bar", ReferenceTotalBar);
