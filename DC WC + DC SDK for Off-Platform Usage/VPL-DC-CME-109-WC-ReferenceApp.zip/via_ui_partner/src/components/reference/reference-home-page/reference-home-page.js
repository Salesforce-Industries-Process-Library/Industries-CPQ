import { LitElement, html } from "lit-element";
import referenceHomePageTemplate from "./reference-home-page-template";
import VlocityDCHomePage from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-home-page/vlocity-dc-home-page";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils";
class ReferenceHomePage extends VlocityDCHomePage {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceHomePageTemplate;
      this.isLayoutEnabled = false;
      this.digitalCommerceSDK = digitalCommerceSDKInstance().digitalCommerce;
      this.digitalCommerceSDK.register("reference-catalog-status-changed", {
        result: this.enableLayout.bind(this)
      });
      this.parentCatalogCode = "";
      this.catalogCode = "";
    }
    static get properties() {
      return {
        isLayoutEnabled: Boolean,
        parentCatalogCode: String,
        catalogCode: String
      };
    }
    render() {
      return this.template(this);
    }
    enableLayout(result){
      this.isLayoutEnabled = result.displayLayout;
    }

}

customElements.define("reference-home-page", ReferenceHomePage);
