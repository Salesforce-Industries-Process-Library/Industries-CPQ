import { LitElement, html } from "lit-element";
 import "../reference-catalog/reference-catalog.js";
 import "../reference-product-list/reference-product-list.js"
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-catalog/vlocity-dc-catalog.js";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-list-view-image/vlocity-dc-offer-list-view-image.js";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-list-view-attribute/vlocity-dc-offer-list-view-attribute.js";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-list-view-price/vlocity-dc-offer-list-view-price.js";

let referenceHomePageTemplate = function prepareTemplate(referenceHomePageComponent) {
  let style = html`
    <style>
      .reference-home-page {
        padding: 0px 100px;
      }
      .reference-home-page-text{
        text-align:center;
        font-weight: bolder;
        margin-bottom: 25px;
      }
      .reference-screen-layout{
        background-color:grey;
      }
      @media only screen and (max-width: 1300px) {
        .reference-home-page {
          padding: 0px 50px;
        }
      }
      @media only screen and (max-width: 1024px) {
        .reference-home-page {
          padding: 0px 10px;
        }
      }
      @media only screen and (max-width: 800px) {
        .reference-home-page {
          padding: 0px 30px;
        }
      }
      @media only screen and (max-width: 400px) {
        .reference-home-page {
          padding: 0px 15px;
        }
      }
      .custom-sub-catalog{
        min-width: 100px;
        font-size: 16px;
        padding: 5px;
        background-color: #fff;
        border: solid 1px #ccc;
      }
      .custom-sub-catalog.active{
        color: #fff;
        background-color: #282b2e;
      }
    </style>
  `;
  let template = html`
    ${style}
    <div class="reference-home-page ${referenceHomePageComponent.isLayoutEnabled?'reference-screen-layout':''}">
      <vlocity-dc-catalog catalogCode="mobile"></vlocity-dc-catalog>
      <vlocity-dc-child-catalog
        parentCatalogCode="${referenceHomePageComponent.parentCatalogCode}"
      >
      </vlocity-dc-child-catalog>
      <reference-product-list
        pageSize="3"
        catalogCode="${referenceHomePageComponent.catalogCode}"
        offers=""
      >
        <div slot="dc-product-list-radio-attribute">123</div>
      </reference-product-list>
    </div>
  `;
  return template;
};

export default referenceHomePageTemplate;
