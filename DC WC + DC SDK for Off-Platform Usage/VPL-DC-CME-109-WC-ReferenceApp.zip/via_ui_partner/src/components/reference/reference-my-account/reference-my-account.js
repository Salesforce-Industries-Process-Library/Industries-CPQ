import { LitElement, html } from "lit-element";
import  VlocityDCMyAccount  from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-my-account/vlocity-dc-my-account";

export default class ReferenceMyAccount extends VlocityDCMyAccount {
  constructor() {
    super(); // always call super() first in the ctor.
  }
}

customElements.define("reference-my-account", ReferenceMyAccount);