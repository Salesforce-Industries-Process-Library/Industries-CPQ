import { LitElement, html } from "lit-element";
import selectNumberTemplate from "./reference-shopping-select-number-template";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils";

class ReferenceSelectNumber extends LitElement {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = selectNumberTemplate;
      this.selectedNumber = "6078 7759";
      this.selectNewNumber = false;
      this.digitalCommerceSDK = digitalCommerceSDKInstance().digitalCommerce;
    }

    static get properties() {
      return {
        selectedNumber: String,
        selectNewNumber: Boolean
      };
    }
    selectNumber(value) {
        this.selectedNumber = value;
    }
    chooseNew(e) {
        this.selectNewNumber = true;
    }
    submitPage() {
        this.digitalCommerceSDK.fire("vlocity-dc-number-selected", "result", {'number':this.selectedNumber})
    }
    render() {
      return this.template(this);
    }
}

customElements.define("reference-shopping-select-number", ReferenceSelectNumber);
