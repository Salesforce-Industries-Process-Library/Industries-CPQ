import { html } from "lit-element";

export const SelectNumberCSS = html`
    <style>
      .choose-number-section {
        padding: 15px;
        margin-top: -30px;
        padding-top: 0px;
        background: #edeff3;
        height: 100%;
        width: 100%;
        position: absolute;
      }
      .options {
        position: absolute;
        margin: auto;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        width: 75%;
        height: 300px;
        border-radius: 3px;
        text-align: center;
      }
      .option {
        padding: 25px 50px;
        border: 1px solid #3c3b3b;
        border-radius: 7px;
        margin-bottom: 70px;
        background: #008ab3;
        font-size: 20px;
        cursor: pointer;
        color: #fff;
      }
      .option:hover {
          background: #00c9ff;
      }
      .select-new-number {
        margin-top: -30px;
        padding-top: 0px;
        height: 100%;
        width: 100%;
        position: absolute;
        background: #fff;
      }
      .select-new-number .title {
        font-weight: bold;
        font-size: 16px;
        position: absolute;
        margin: auto;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        text-align: center;
        margin-top: 30px;
        letter-spacing: 0.2px;
      }
      .card {
        transition: transform .5s ease-out 0s,margin-left .5s ease-in-out 0s,opacity .5s ease-in-out 0s,left .5s ease-out 0s,top .5s ease-out 0s,-webkit-transform .5s ease-out 0s;
        margin-left: -112px;
        position: absolute;
        width: 225px;
        margin: auto;
        right: 0;
        bottom: 0;
        left: 0;
        text-align: center;
        top: 100px;
      }
      .card .shadow {
        content: " ";
        display: block;
        position: absolute;
        width: 86%;
        height: 90%;
        left: 8%;
        top: 5%;
        z-index: 0;
        box-shadow: 0 80px 80px 0 rgba(255,255,47,0.07);
      }
      .card .shadow.bg.bg-small {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        vertical-align: middle;
        display: inline-block;
      }
      .card .label-phone-number {
        opacity: 1;
        font-size: 12px;
        color: #fff;
        position: absolute;
        left: 20px;
        top: 20px;
      }
      .card .value-phone-number {
        position: absolute;
        font-size: 28px;
        color: #003a5c;
        left: 24px;
        top: 40px;
        padding: 0px 5px;
      }
      .card .label-counter-text {
        position: absolute;
        font-size: 13px;
        color: #fff;
        left: 20px;
        top: 95px;
      }
      .card .label-counter {
        position: absolute;
        font-size: 14px;
        color: #fff;
        left: 20px;
        top: 115px;
        opacity: 0.85;
        font-weight: bold;
      }
      .custom-select {
        width: 200px;
        position: absolute;
        top: 300px;
        margin: auto;
        right: 0;
        bottom: 0;
        left: 0;
        text-align: center;
      }
      .footer-section {
        height: 70px;
        position: fixed;
        bottom: 0px;
        width: 100%;
      }
      .footer-section .select-number{
        background-color: #008ab4;
        width: 50%;
        border-radius: 10px;
        margin: 0 auto;
        margin-top: 13px;
        padding: 5px 40px;
        text-align: center;
        color: #fff;
        max-width: 300px;
        cursor: pointer;
      }
    </style>
`;
