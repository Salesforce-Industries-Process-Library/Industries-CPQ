import { html } from "lit-element";
import { SelectNumberCSS } from "./reference-shopping-select-number-css";

let selectNumberTemplate = function prepareTemplate(_this) {
  let template = html`
    ${SelectNumberCSS}
    <slot name="selectNumberTemplate">
      ${!_this.selectNewNumber ?html`
        <div class="choose-number-section">
            <div class="options">
                <div class="option" @click="${e => { _this.chooseNew()}}">Select a new number</div>
                <div class="option" @click="${e => { _this.submitPage()}}">Keep your number</div>
            </div>
        </div>
      `:html`
        <div class="select-new-number">
            <p class="title">Select a new number</p>
            <div class="card active card-6 timeout">
                <div class="shadow"></div>
                <svg width="225px" height="154px" viewBox="0 0 225 154" version="1.1" xmlns="http://www.w3.org/2000/svg" src="/static/media/sim-white-small.ffb8188a.svg" class="bg bg-small">
                <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->
                <title>SIM/small/white</title>
                <desc>Created with Sketch.</desc>
                <defs>
                    <path style="fill: #008ab3" d="M163.693359,0 L183.777036,0 L225,39.1414526 L225,142 C225,148.627417 219.627417,154 213,154 L12,154 C5.372583,154 0,148.627417 0,142 L0,109.722894 C2.44988274,109.400254 4.34083601,107.303933 4.34083601,104.765957 L4.34083601,49.2340426 C4.34083601,46.6960666 2.44988274,44.5997464 8.32667268e-17,44.2771058 L0,12 C0,5.372583 5.372583,-1.21743675e-15 12,0 L135.364356,0 C136.066513,1.91229257 137.903634,3.27659574 140.059404,3.27659574 L158.998311,3.27659574 C161.154082,3.27659574 162.991202,1.91229257 163.693359,3.3094083e-12 Z" id="path-1"></path>
                    <filter x="-3.6%" y="-2.6%" width="107.1%" height="110.4%" filterUnits="objectBoundingBox" id="filter-2">
                        <feOffset dx="0" dy="4" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
                        <feGaussianBlur stdDeviation="2" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
                        <feColorMatrix values="0 0 0 0 0.68627451   0 0 0 0 0.698039216   0 0 0 0 0.701960784  0 0 0 0.5 0" type="matrix" in="shadowBlurOuter1"></feColorMatrix>
                    </filter>
                </defs>
                <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="SIM/small/white">
                        <g id="sim1">
                            <g id="Combined-Shape">
                                <use fill="black" fill-opacity="1" filter="url(#filter-2)" xlink:href="#path-1"></use>
                                <use fill="#FFFFFF" fill-rule="evenodd" xlink:href="#path-1"></use>
                            </g>
                            
                        </g>
                    </g>
                </g>
                </svg>
                <div class="label-phone-number">Phone Number</div>
                <div class="value-phone-number">${_this.selectedNumber}</div>
                <div class="label-counter-text">SIM</div>
                <div class="label-counter">88 $</div>
            </div>
            <div class="custom-select" style="width:200px;" @change=${e => _this.selectNumber(e.target.value)}>
                <select>
                    <option value="6078 7759">6078 7759</option>
                    <option value="6078 7769">6078 7769</option>
                    <option value="6078 4759">6078 4759</option>
                    <option value="6078 8759">6078 8759</option>
                    <option value="6078 7760">6078 7760</option>
                    <option value="6078 7761">6078 7761</option>
                    <option value="6078 7762">6078 7762</option>
                    <option value="6078 7763">6078 7763</option>
                    <option value="6078 7789">6078 7789</option>
                    <option value="6078 7719">6078 7719</option>
                </select>
            </div>
            <div class="footer-section">
                <div class="select-number" @click="${e => { _this.submitPage()}}">Select this number</div>
            </div>
        </div>
      `}
    </slot>
  `;
  return template;
};

export default selectNumberTemplate;
