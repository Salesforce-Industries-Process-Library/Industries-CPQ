import { LitElement, html } from "lit-element";

let dcProductListViewPrice = function prepareTemplate(priceComponent) {
  let style = html`
    <style>
      :host(.pricelist) {
        flex: 3;
        padding: 15px 0px 0px 15px;
      }
      .reference-tile-text-small {
        color: #556a8c;
        font-size: 12px;
        line-height: 16px;
      }
      .reference-price-items .reference-product-name {
        color: #16325c;
        font-size: 20px;
        line-height: 26px;
        padding-right: 5px;
      }
      .reference-price-items .reference-product-price {
        color: #16325c;
        font-size: 27px;
        line-height: 50px;
      }
      .reference-product-discount-price {
        color: #16325c;
        font-size: 27px;
        line-height: 50px;
      }
      .reference-price-text{
        margin-left:7%;
      }
      .reference-product-detail {
        color: #556a8c;
        font-size: 12px;
        line-height: 16px;
        flex: 3;
      }
      .nds-size--1-of-2 {
        width: 50%;
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
      }
      .nds-wrap {
        flex-wrap: wrap;
        -ms-flex-align: start;
        align-items: flex-start;
      }
      .nds-grid {
        display: flex;
      }
      .nds-size--1-of-3 {
        width: 33.3333333333%;
        -ms-flex: 0 0 33.3333333333%;
        flex: 0 0 33.3333333333%;
        max-width: 33.3333333333%;
      }

      @media only screen and (max-width: 767px) {
        .nds-grid.listview {
          display: block;
        }
        .listview .nds-size--1-of-2.reference-price-items {
          width: 100%;
          max-width: 100%;
          text-align: center;
          display: block;
        }
        .reference-product-detail {
          display: none;
        }
        .reference-tile-text-small.listview {
          text-align: center;
          display: block;
          width: 100%;
          max-width: 100%;
        }
      }
    </style>
  `;
  let dcProductListViewPriceTemplate = html`
    ${style}
    <div class="reference-price-text" class="via-nds">
      <slot name="listViewPriceSlot">
        <div
          class="${
            priceComponent.displayview === "list"
              ? "reference-tile-text-small listview"
              : "reference-tile-text-small"
          }"
        >
          Basic Line
        </div>
        <div
                  class="${
                    priceComponent.displayview === "list"
                      ? "nds-grid nds-wrap reference-product-price-wrapper listview"
                      : "nds-grid nds-wrap reference-product-price-wrapper gridview"
                  }"
                >
                  <div
                    class="nds-size--1-of-2 reference-price-items">
                    <div class="reference-product-price">
                      <span class="reference-product-discount-price">
                        <b>${priceComponent.priceresult && priceComponent.priceresult.oneTimeCharge ? priceComponent.priceresult.oneTimeCharge:"NA"}</b>
                        <span class="reference-tile-text-small">$</span>
                      </span>
                    </div>
                    
                  </div>
                  </div>
      </slot>
    </div>
  `;
  return dcProductListViewPriceTemplate;
};

export default dcProductListViewPrice;
