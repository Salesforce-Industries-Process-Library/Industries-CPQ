import { LitElement, html } from "lit-element";
import referenceListViewPriceTemplate from "./reference-list-view-price-template.js";
import VlocityListViewPrice from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-list-view-price/vlocity-dc-offer-list-view-price.js";

class ReferenceListViewPrice extends VlocityListViewPrice {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceListViewPriceTemplate;
    }
    render() {
      return this.template(this);
    }
}

customElements.define("reference-list-view-price", ReferenceListViewPrice);
