import { LitElement, html } from "lit-element";
import selectionPageTemplate from "./reference-selection-page-template";
import VlocityDcSelectionPage from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-config/vlocity-dc-offer-config.js";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils.js";

class ReferenceSelectionPage extends VlocityDcSelectionPage {
    constructor() {
        super();
        this.template = selectionPageTemplate;
    }
    render() {
        return this.template(this);
    }
}

customElements.define("reference-selection-page", ReferenceSelectionPage);