import { LitElement, html } from "lit-element";
import * as icons from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-icons/vlocity-dc-icons";

let selectionPageTemplate = function prepareTemplate(offerConfigComponent) {
  let {
    offer,
    loading,
    paymentChoiceStr,
    catalogCode,
    offerCode,
    mediaSource,
    productGroups
  } = offerConfigComponent;
  let template = html`
    <link
      type="text/css"
      rel="stylesheet"
      href="${offerConfigComponent.ndsLibPath}"
    />
    <div class="nds-dc-offer_config">
      <div class="nds-dc-offer-config-title-container">
        <div class="nds-dc-plan-title">${offer.name}</div>
        <span class="nds-dc-underline-title"></span>
        ${offerConfigComponent.showToast
          ? html`
              <vlocity-dc-toast
                title="Error"
                message=${offerConfigComponent.errorMessage}
                styleType="error"
                duration="2000"
              >
              </vlocity-dc-toast>
            `
          : ``}
      </div>
      <div class="via-nds nds-dc-offer-config-container">
        ${offer && Object.keys(offer).length != 0
          ? html`
              <div class="nds-dc-media-container">
                <vlocity-dc-media-viewer
                  .mediaSource="${mediaSource}"
                  .displayThumbnails="${true}"
                >
                </vlocity-dc-media-viewer>
              </div>
              <div class="nds-dc-offer-config-details">
                <vlocity-dc-offer-config-details .currentOffer="${offer}">
                </vlocity-dc-offer-config-details>
              </div>
            `
          : ""}
      </div>
      <div class="nds-dc-offer-group-sections">
        ${productGroups
          ? html`
              <vlocity-dc-offer-addons
                name="addons"
                class="active"
                catalogCode="${catalogCode}"
                offerCode="${offerCode}"
                .productGroups="${productGroups}"
              >
              </vlocity-dc-offer-addons>
            `
          : html``}
      </div>
      <div class="nds-dc-continue-btn-container">
        <slot name="dc-add-to-cart-btn">
          <button
            class="nds-button nds-button_brand nds-dc-continue-btn"
            @click="${e => {
              offerConfigComponent.addToCart();
            }}"
          >Add To Cart
          </button>
        </slot>
      </div>
    </div>
    ${loading
      ? html`
          <div class="nds-spinner_container">
            <div
              class="nds-spinner_brand nds-spinner"
              aria-hidden="false"
              role="alert"
            >
              ${icons.spinner}
            </div>
          </div>
        `
      : ""}
    </div>
  `;
  return template;
};

export default selectionPageTemplate;
