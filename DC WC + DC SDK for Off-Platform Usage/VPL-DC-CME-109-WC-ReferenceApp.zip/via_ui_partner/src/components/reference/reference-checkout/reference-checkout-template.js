import {LitElement,  html } from "lit-element";

let h3hCheckoutTemplate = function prepareTemplate(_this) {
  let style = html`
    <style>
      .reference-checkout-wrapper {
        height: 100%;
        width: 100%;
        position: absolute;
      }
    </style>
  `;
  let template = html`
    ${style}
    ${_this.loading ? html`<reference-loader></reference-loader>`:``}
    <div class="reference-checkout-wrapper">
      <embed src="https://kashdemo--vlocity-cmt.visualforce.com/apex/vlocity_cmt__OmniScriptUniversalPage?id={0}&layout=lightning#/OmniScriptType/TRNG/OmniScriptSubType/BrainTreePayment/OmniScriptLang/English/ContextId/{0}/PrefillDataRaptorBundle//true" frameborder="0" width="100%" height="100%"></embed>
    </div>
  `;
  return template;
};

export default h3hCheckoutTemplate;
