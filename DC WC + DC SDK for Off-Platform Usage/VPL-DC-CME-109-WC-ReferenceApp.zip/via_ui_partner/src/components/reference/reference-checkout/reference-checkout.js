import { LitElement, html } from "lit-element";
import VlocityDCCheckout from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-checkout/vlocity-dc-checkout.js";
class ReferenceCheckout extends VlocityDCCheckout {
    constructor() {
      super();
    }
}
customElements.define("reference-checkout", ReferenceCheckout);