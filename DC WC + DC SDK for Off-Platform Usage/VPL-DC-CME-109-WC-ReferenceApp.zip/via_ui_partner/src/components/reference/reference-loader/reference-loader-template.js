import { LitElement, html } from "lit-element";

let referenceLoaderTemplate = function prepareTemplate(referenceHomePageComponent) {
  let style = html`
    <style>
      .global_loading {
          position: fixed;
          z-index: 100;
          width: 100%;
          height: 100%;
          top: 0;
          left: 0;
          text-align: center;
          display: -ms-flexbox;
          display: flex;
          transition: opacity .3s,-webkit-transform .3s;
          transition: transform .3s,opacity .3s;
          transition: transform .3s,opacity .3s,-webkit-transform .3s;
          transform: rotateY(-90deg);
          opacity: 0;
          pointer-events: none
      }

      .global_loading.show {
          opacity: 1;
          pointer-events: all;
          transform: rotateY(0deg);
          background: rgba(271, 271, 271, 0.9);
      }

      .global_loading .loadingContainer {
          margin: auto;
          display: inline-block;
          width: 115px;
          height: 115px;
          border-radius: 100%;
          line-height: 115px;
          background: hsla(0,0%,100%,.95);
          text-align: center;
          position: relative
      }

      .global_loading .logo {
          width: 55px;
          height: 31px;
          position: absolute;
          left: 34px;
          top: 42px;
          -webkit-animation-duration: 3s;
          animation-duration: 3s;
          -webkit-animation-name: flip;
          animation-name: flip;
          -webkit-animation-iteration-count: infinite;
          animation-iteration-count: infinite
      }

      .global_loading .logo.green g,.global_loading .logo.green path,.global_loading .logo.green polygon {
          fill: red
      }

      .global_loading .logo.purple {
          -webkit-animation-delay: 1s;
          animation-delay: 1s;
          opacity: 0
      }

      .global_loading .logo.purple g,.global_loading .logo.purple path,.global_loading .logo.purple polygon {
          fill: red
      }

      .global_loading .logo.blue {
          -webkit-animation-delay: 2s;
          animation-delay: 2s;
          opacity: 0
      }

      .global_loading .logo.blue g,.global_loading .logo.blue path,.global_loading .logo.blue polygon {
          fill: red
      }

      @-webkit-keyframes flip {
          0% {
              -webkit-transform: rotateY(-90deg);
              transform: rotateY(-90deg);
              opacity: 1
          }

          6.67% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 1
          }

          30% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 1
          }

          36.67% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 0
          }

          to {
              opacity: 0;
              -webkit-transform: rotateY(-90deg);
              transform: rotateY(-90deg)
          }
      }

      @keyframes flip {
          0% {
              -webkit-transform: rotateY(-90deg);
              transform: rotateY(-90deg);
              opacity: 1
          }

          6.67% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 1
          }

          30% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 1
          }

          36.67% {
              -webkit-transform: rotateY(0deg);
              transform: rotateY(0deg);
              opacity: 0
          }

          to {
              opacity: 0;
              -webkit-transform: rotateY(-90deg);
              transform: rotateY(-90deg)
          }
      }
    </style>
  `;
  let template = html`
    ${style}
    <div class="via-nds">
    <div class="nds-spinner_container">
      <div
        class="nds-spinner_brand nds-spinner"
        aria-hidden="false"
        role="alert"
      >
        <svg
          version="1.1"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 100 100"
        >
          <circle cx="6" cy="50">
            <animateTransform
              attributeName="transform"
              dur="1s"
              type="translate"
              values="0 15 ; 0 -15; 0 15"
              repeatCount="indefinite"
              begin="0.1"
            />
          </circle>
          <circle cy="50">
            <animateTransform
              attributeName="transform"
              dur="1s"
              type="translate"
              values="0 10 ; 0 -10; 0 10"
              repeatCount="indefinite"
              begin="0.2"
            />
          </circle>
          <circle cy="50">
            <animateTransform
              attributeName="transform"
              dur="1s"
              type="translate"
              values="0 5 ; 0 -5; 0 5"
              repeatCount="indefinite"
              begin="0.3"
            />
          </circle>
        </svg>
      </div>
    </div>
  </div>
  `;
  return template;
};

export default referenceLoaderTemplate;
