import { LitElement, html } from "lit-element";
import referenceLoaderTemplate from "./reference-loader-template";
class ReferenceHomePage extends LitElement {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceLoaderTemplate;
    }
    render() {
      return this.template(this);
    }

}

customElements.define("reference-loader", ReferenceHomePage);
