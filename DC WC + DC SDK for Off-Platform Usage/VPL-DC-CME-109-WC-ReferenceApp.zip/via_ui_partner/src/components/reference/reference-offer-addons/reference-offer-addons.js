import VlocityDCOfferAddons from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-addons/vlocity-dc-offer-addons";
class ReferenceOfferAddons extends VlocityDCOfferAddons {
    constructor() {
        super();
    }
}
customElements.define("reference-offer-addons", ReferenceOfferAddons);
