import { html } from "lit-element";

let shoppingEachProductTemplate = function prepareTemplate(
  shoppingEachProductComponent
) {
  let { productOnly, categoryname, product } = shoppingEachProductComponent;
  let style = html`
    <style>
      .product-details {
        display: table;
        width: 100%;
        margin: 10px 0px;
      }
      .product-total {
        display: table-cell;
        width: 35%;
        text-align: end;
      }
      .product-total .price {
        color: #003a5c;
        font-size: 20px;
      }
      .product-details .charge-details {
        opacity: 0.4;
      }
      .empty-div {
        width: 5%;
        display: table-cell;
      }
      .product-name {
        display: table-cell;
        width: 55%;
        max-width: 10px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        font-size: 14px;
        line-height: 1.3;
      }
      @media only screen and (max-width: 480px) {
        .product-total .price {
          font-size: 20px;
        }
      }
    </style>
  `;
  let dcShoppingEachProduct = html`
    <link
      type="text/css"
      rel="stylesheet"
      href="${shoppingEachProductComponent.ndsLibPath}"
    />
    ${style}
    <slot name="shoppingDetailsTemplate">
        <div class="product-details">
          <div class="empty-div"></div>
          <div class="product-name">${product.name}</div>
          <div class="product-total">
            <span class="price">${product.priceInfo.oneTimeCharge}</span>
            <span class="charge-details">/month</span>
          </div>
          <div class="empty-div"></div>
        </div>
    </slot>
  `;
  return dcShoppingEachProduct;
};

export default shoppingEachProductTemplate;
