import { LitElement, html } from "lit-element";
import shoppingEachProductTemplate from "./reference-shopping-product-details-template";
import VlocityDCShoppingEachProduct from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-shopping-nested-offer/vlocity-dc-shopping-nested-offer";

class ReferenceShoppingProductDetails extends VlocityDCShoppingEachProduct {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = shoppingEachProductTemplate;
    }
    render() {
      return this.template(this);
    }  
}

customElements.define("reference-shopping-product-details", ReferenceShoppingProductDetails);
