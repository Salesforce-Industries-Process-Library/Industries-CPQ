import { LitElement, html } from "lit-element";
import VlocityDCShoppingCart from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-shopping-cart/vlocity-dc-shopping-cart";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils";
class ReferenceShoppingCart extends VlocityDCShoppingCart {
    constructor() {
      super(); // always call super() first in the ctor.
    }

}

customElements.define("reference-shopping-cart", ReferenceShoppingCart);
