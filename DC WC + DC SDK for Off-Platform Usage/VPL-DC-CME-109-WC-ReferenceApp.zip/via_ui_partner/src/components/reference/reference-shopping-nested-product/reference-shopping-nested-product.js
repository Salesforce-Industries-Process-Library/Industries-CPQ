import { LitElement, html } from "lit-element";
import shoppingNestedProductTemplate from "./reference-shopping-nested-product-template";
import VLocityDCShoppingNestedProduct from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-shopping-nested-offer/vlocity-dc-shopping-nested-offer";

class ReferenceShoppingNestedProduct extends VLocityDCShoppingNestedProduct {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = shoppingNestedProductTemplate;
    }

    static get properties() {
      return {
        fromparent: Boolean,
        nestedProduct: Object,
        categoryname: String,
        parentindex: String,
        lineItemsAvailable: Boolean,
        productGroupsAvailable: Boolean
      };
    }

    render() {
      return this.template(this);
    }
}

customElements.define("reference-shopping-nested-product", ReferenceShoppingNestedProduct);
