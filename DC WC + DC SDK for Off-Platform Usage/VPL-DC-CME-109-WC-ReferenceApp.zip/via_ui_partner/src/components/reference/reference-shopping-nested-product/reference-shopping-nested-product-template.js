import { html } from "lit-element";

let shoppingNestedProductTemplate = function prepareTemplate(
  shoppingNestedProductComponent
) {
  let {
    lineItemsAvailable,
    nestedProduct,
    parentIndex,
    categoryname,
    productGroupsAvailable
  } = shoppingNestedProductComponent;
  let dcShoppingNestedProduct = html`
    <link
      type="text/css"
      rel="stylesheet"
      href="${shoppingNestedProductComponent.ndsLibPath}"
    />
    <slot name="nested-product-slot">
      <div class="via-nds">
        <div class="${shoppingNestedProductComponent.getNestedProductClass()}">
          ${nestedProduct.lineItems
            ? html`
                <div>
                  ${nestedProduct.lineItems &&
                    nestedProduct.lineItems.map(
                      (product, index) => html`
                        <div class="vlocity-dc-product-attribute">
                          <reference-shopping-product-details
                            .product="${product}"
                            .categoryname="${categoryname}"
                            .productOnly="${false}">
                          </reference-shopping-product-details>
                        </div>
                      `
                    )}
                </div>
              `
            : html``}
          ${productGroupsAvailable
            ? html`
                <div>
                  ${nestedProduct.cartItemGroups &&
                    nestedProduct.cartItemGroups.map(
                      (childProductGroup, index) => html`
                        <div>
                          <reference-shopping-nested-product
                            key="${childProductGroup.productId}"
                            .fromparent="${false}"
                            .nestedProduct="${childProductGroup}"
                            .categoryname="${categoryname}"
                            .parentindex="${index}"
                          >
                          </reference-shopping-nested-product>
                        </div>
                      `
                    )}
                </div>
              `
            : html``}
        </div>
      </div>
    </slot>
  `;
  return dcShoppingNestedProduct;
};

export default shoppingNestedProductTemplate;
