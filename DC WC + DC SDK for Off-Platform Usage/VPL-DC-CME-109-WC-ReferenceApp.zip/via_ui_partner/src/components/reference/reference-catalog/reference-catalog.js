import { LitElement, html } from "lit-element";
import VlocityDCMainCatalog from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-catalog/vlocity-dc-catalog";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils";
import referenceCatalogPageTemplate from "./reference-catalog-template";

export default class ReferenceHCatalogPage extends VlocityDCMainCatalog {
  constructor() {
    super(); // always call super() first in the ctor.
    this.digitalCommerceSDK = digitalCommerceSDKInstance().digitalCommerce;
    this.template = referenceCatalogPageTemplate;
    this.menuFlag=false;
  }
  render() {
    return this.template(this);
  }
  openOrCloseCatalog(){
    this.menuFlag=!this.menuFlag;
    this.digitalCommerceSDK.fire("reference-catalog-status-changed", "result", {
      displayLayout: this.menuFlag
    });
  }
}

customElements.define("reference-catalog", ReferenceHCatalogPage);