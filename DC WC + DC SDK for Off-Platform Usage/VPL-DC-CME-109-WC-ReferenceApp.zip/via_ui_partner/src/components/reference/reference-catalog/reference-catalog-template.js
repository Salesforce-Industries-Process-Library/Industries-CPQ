import { LitElement, html } from "lit-element";
import * as icons from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-icons/vlocity-dc-icons.js";
import "../reference-sub-catalog/reference-sub-catalog.js";

let active = false;

let catalogTemplate = function prepareTemplate(ele) {
  let template = html`
    <reference-sub-catalog active="" pageSize="3" title="Mobiles">
    </reference-sub-catalog>
  `;

  return template;
};

export default catalogTemplate;
