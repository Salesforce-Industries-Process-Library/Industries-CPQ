import { LitElement, html } from "lit-element";
import referenceGridViewTemplate from "./reference-grid-view-template.js";
import VlocityGridView from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-grid-view/vlocity-dc-offer-grid-view.js";

class ReferenceGridView extends VlocityGridView {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceGridViewTemplate;
    }
    render() {
      return this.template(this);
    }
}

customElements.define("reference-grid-view", ReferenceGridView);
