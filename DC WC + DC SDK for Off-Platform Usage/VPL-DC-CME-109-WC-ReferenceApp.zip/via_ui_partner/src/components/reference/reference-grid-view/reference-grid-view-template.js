import { LitElement, html } from "lit-element";

let productGridViewTemplate = function prepareTemplate(offerGridViewComponent) {
  let template = html`
    ${offerGridViewComponent.offers
      ? html`
          <link
            type="text/css"
            rel="stylesheet"
            href="${offerGridViewComponent.ndsLibPath}"
          />
          <slot name="dc-offer-grid-view-wrapper">
            <div class="via-nds">
              <div class="nds-grid nds-wrap nds-dc-offer-grid-view">
                ${offerGridViewComponent.offers.map(
                  (offer, index) => html`
                    <span
                      class="nds-size--1-of-1 nds-medium-size--1-of-2 nds-large-size--1-of-3 nds-dc-offer-board"
                    >
                      <div class="nds-dc-offer-item-tile">
                        ${offer.promoCode
                          ? html`
                              <div class="nds-dc-offer-tag">
                                ${offerGridViewComponent.digitalCommerceTranslation.translate(
                                  "DCSpecialOffer"
                                )}
                                - ${offer.promoCode}
                              </div>
                            `
                          : ""}
                        <ul class="nds-has-dividers_around-space">
                          <li class="nds-dc-nds-item">
                            <a
                              id="${offer.Name}"
                              @click=${() => {
                                offerGridViewComponent.offerSelected(offer);
                              }}
                            >
                              <article
                                class="qnds-tile qnds-tile_board nds-tile_board nds-dc-offer-item"
                              >
                                ${offer.attachments && offer.attachments.length
                                  ? html`
                                      <vlocity-dc-offer-list-view-image
                                        .offerAttachments="${offer.attachments}"
                                        displayMode="grid"
                                      ></vlocity-dc-offer-list-view-image>
                                    `
                                  : ""}

                                <div class="nds-dc-offer-item-details">
                                  <slot name="dc-attributes">
                                    <div class="nds-grid nds-wrap">
                                      <div class="nds-size--1-of-2 nds-put-right-border">
                                        <div class="nds-dc-offer-name">
                                          ${offer.name}
                                        </div>
                                        <div class="nds-dc-tile-text">
                                          Apple
                                        </div>
                                      </div>
                                      <div class="nds-size--1-of-2">
                                      ${offer.priceInfo
                                        ? html`
                                        <vlocity-dc-offer-list-view-price
                                          class="pricelist"
                                          .priceResult="${offer.priceInfo}"
                                          .isOfferTypePromotion="${
                                            offer.promoCode ? true : false
                                          }"
                                          displayMode="grid"
                                        > 
                                          <style>
                                            .custom-price{
                                              text-align: right;
                                            }
                                            .price-label{
                                              color: #54698d;
                                              font-size: .875rem;
                                              line-height: 1.875rem;
                                            }
                                            .price-value{
                                              color: #16325c;
                                              font-size: 1.25rem;
                                              line-height: 1.625rem;
                                              font-weight: 700;
                                            }
                                          </style>
                                          <div class="custom-price" slot="dc-list-view-price-wrapper">
                                            <div class="price-label">One-time</div>
                                            <div class="price-value">
                                              $${offer.priceInfo.oneTimeCharge}
                                            </div>
                                          </div>
                                        </vlocity-dc-offer-list-view-price>`
                                        : ""}
                                      </div>
                                    </div>
                                    ${offer.attributes
                                      ? html`
                                          <vlocity-dc-offer-list-view-attribute
                                            .attributeCategories="${offer.attributes}"
                                          ></vlocity-dc-offer-list-view-attribute>
                                        `
                                      : ""}
                                  </slot>
                                </div>
                                <button class="nds-button nds-button_brand full-width">View Offer</button>
                              </article>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </span>
                  `
                )}
              </div>
            </div>
          </slot>
        `
      : ""}
  `;
  return template;
};

export default productGridViewTemplate;
