import { LitElement, html } from "lit-element";

let productConfigurationsTemplate = function prepareTemplate(productConfigurations) {
  let count = productConfigurations.stepCount;
  let stepsConfiguration = productConfigurations.stepsConfiguration.stepsIntervalArray;
  let currentValue = productConfigurations.currentValue;
  let template = html`
    <link
      type="text/css"
      rel="stylesheet"
      href="${productConfigurations.ndsLibPath}"
    />
    <div class="reference-product-configurations">
      <div>
        <span class="reference-child-name">${productConfigurations.child.description}</span>
        <span class="reference-child-price">
          <span class="currency">$${productConfigurations.child.priceInfo.oneTimeCharge}</span>
          <span class="reference-price-interval">/month</span>
        </span>
      </div>
      <div class="range-container">
        <div style="background: linear-gradient(to right, #008ab3 0%, #008ab3 ${productConfigurations.currentValue}%, #fff ${productConfigurations.currentValue}%, #fff 100%)" class="range">
          <input style="color:#555" step=${productConfigurations.stepsConfiguration.stepsRange} type="range" min=${stepsConfiguration[0]} max=${stepsConfiguration[stepsConfiguration.length-1]} value=${Math.round(productConfigurations.child.attributes[0].userValues)}
          @change="${
            e => {
            productConfigurations.trackValueChanged(e);
            }
          }"
          @input="${
            e => {
            productConfigurations.getTrackStyle(e);
            }
          }">
        </div>
        <div class="range-labels">
        ${
          stepsConfiguration.map(
            (product, index) => 
            index<stepsConfiguration.length-2?
            html`<li  style="left:${index==0?0:-((index*4)-4)}px; width: ${productConfigurations.width}%;" class=${product==Math.round(productConfigurations.child.attributes[0].userValues)?"active selected":""}>${product}</li>`:
            html`${
              index<stepsConfiguration.length-1?
              html`<li class=${product==Math.round(productConfigurations.child.attributes[0].userValues)?"active selected":""} style="left:${-((index*4)-4)}px; width: ${productConfigurations.width}%">${product}</li>`:
              html`<li class=${product==Math.round(productConfigurations.child.attributes[0].userValues)?"active selected":""} style="width:0px;left: -8px;">${product}</li>`
            }`
          )
        }
        </div>
      </div>
    </div>
  `
  return template;
};

export default productConfigurationsTemplate;
