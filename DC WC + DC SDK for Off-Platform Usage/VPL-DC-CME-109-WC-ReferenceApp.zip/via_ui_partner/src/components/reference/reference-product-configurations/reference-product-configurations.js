
import { LitElement, html } from "lit-element";
import productConfigurationsTemplate from "./reference-product-configurations-template.js";
import VlocityDCProductConfigurations from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-configurations/vlocity-dc-offer-configurations.js";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils.js";

class ReferenceProductConfigurations extends VlocityDCProductConfigurations {
    constructor() {
        super();
        this.template = productConfigurationsTemplate;
        this.digitalCommerceSDK = digitalCommerceSDKInstance().digitalCommerce;
    }
    static get properties() {
        return {
            stepsConfiguration: Object,
            child: Object
        };
      }
    connectedCallback() {
        super.connectedCallback();
        this.userSelectedValue = Math.round(this.child.attributes[0].userValues);
        this.intervalArray = this.child.attributes[0].values.map(function(item) {
            return Math.round(item.value);
        }).sort(this.order);
        this.step = this.intervalArray[1] - this.intervalArray[0];
        this.stepsConfiguration = {stepsRange:this.step,stepsIntervalArray:this.intervalArray};
        this.width= 100/(this.stepsConfiguration.stepsIntervalArray.length-1);
        this.currentValue = this.stepsConfiguration.stepsIntervalArray.findIndex(x => x === this.userSelectedValue)*this.width;
        this.dynamicStyles = ' ';
    }
    render() {
        return this.template(this);
    }

    order(a, b) {
        return a < b ? -1 : (a > b ? 1 : 0);
    }

    trackValueChanged(el) {
        console.log('el ', el);
        let val = Math.round(el.currentTarget.value);
        let curVal = Math.round((val / this.step + 1));
        if(this.stepsConfiguration.stepsIntervalArray[0] > 0) {
            curVal--;
        }
        let style = '';
        var labels = this.shadowRoot.querySelectorAll('.range-labels > li');
        let prefs = ['webkit-slider-runnable-track'];
        this.userSelectedValue = val;
        this.child.attributes[0].userValues = val;
        const detail = {
            field: "AttributeCategoryLineItems",
            productHierarchyPath: this.child.productHierarchyPath,
            id: this.child.id,
            value: {
              label: this.child.attributes[0].label,
              userValue: val.toString()
            }
        };
        this.digitalCommerceSDK.fire("reference-price-updated","result", detail);
        // Set active label
        labels.forEach(item => {
            item.className = '';
        });
        
        let curLabel = labels[curVal-1];
        for (var i = 0;i < curVal-1;i++)  {
            labels[i].className = 'selected';
        }
        
        curLabel.className = 'active selected';
        
        // Change background gradient
        for (var i = 0; i < prefs.length; i++) {
            this.currentValue = this.stepsConfiguration.stepsIntervalArray.findIndex(x => x === this.userSelectedValue)*this.width;
        }

        this.dynamicStyles = style;
    }
    getTrackStyle(el) {
        console.log('el ', el);
        let val = Math.round(el.currentTarget.value);
        this.currentValue = this.stepsConfiguration.stepsIntervalArray.findIndex(x => x === val)*this.width;
    }

    getStaticStyles() {
        return html`
            <style>
                .range {
                    position: relative;
                    height: 6px;
                    width: 100%;
                    margin:0;
                }

                .range input {
                    width: 100%;
                    position: absolute;
                    top: 1px;
                    height: 0;
                    -webkit-appearance: none;
                    z-index: 10;
                }

                .range input::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    width: 18px;
                    height: 18px;
                    margin: -8px 0  0;
                    margin-left:0px;
                    margin-right:0px;
                    border-radius: 50%;
                    background: #008ab3;
                    cursor: pointer;
                    border: 0 !important;
                }

                .range input::-webkit-slider-runnable-track {
                    width: 100%;
                    height: 2px;
                    cursor: pointer;
                    background: #555;
                }

                .range input:focus { 
                    background: none;
                    outline: none;
                }
                .range-labels {
                    margin: 0;
                    padding-left: 0;
                    list-style: none;
                }
                .range-labels li {
                    position: relative;
                    float: left;
                    width: ${this.width}%;
                    text-align: center;
                    color: #555;
                    font-size: 14px;
                    cursor: pointer;
                    list-style: none;
                    text-align: left;
                    top: -31px;
                }
                .range-labels li::before {
                    position: absolute;
                    top: 23px;
                    content: "";
                    margin: 0 auto;
                    width: 9px;
                    height: 9px;
                    background: #555;
                    border-radius: 50%;
                }
                .range-labels span::before {
                    position: absolute;
                    top: -8px;
                    right:-15px;
                    content: "";
                    margin: 0 auto;
                    width: 9px;
                    height: 9px;
                    background: #b2b2b2;
                    border-radius: 50%;
                }
                .range-labels .active {
                    color: #008ab3;
                }
                .range-labels .selected::before {
                    background: #008ab3;
                }
                .range-labels .active.selected::before {
                    display: none;
                }
                .range-container {
                    height: 100px;
                    padding:10px;
                    box-sizing: border-box;
                    clear: both;
                    padding-left: 5%;
                    padding-right: 5%;
                }
                .reference-child-name {
                    color: #555;
                    float: left;
                    margin-left: 3%;
                    font-weight: bold;
                    top: -20px;
                    position: relative;
                }
                .reference-child-price {
                    float: right;
                    color: #555;
                    margin-right:3%;
                    margin-top: -30px;
                }
                .reference-child-price .currency {
                    font-size: 20px;
                    font-weight: bold;
                }

                .reference-price-interval {
                    color: #555;
                }
            </style>
        `;
    }

    attributeChangedCallback(attrName, oldVal, newVal) {
        if (attrName == "childName" && newVal) {
            this.childName = JSON.parse(newVal) || '';
        }
    }

    static get properties() {
        return {
            dynamicStyles: String,
            currentValue:Number
        }
    }
}

customElements.define("reference-product-configurations", ReferenceProductConfigurations);