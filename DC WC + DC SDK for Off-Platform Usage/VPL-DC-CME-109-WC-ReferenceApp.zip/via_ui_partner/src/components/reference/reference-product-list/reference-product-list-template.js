import { LitElement, html } from "lit-element";
import "../reference-grid-view/reference-grid-view";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-list-view/vlocity-dc-offer-list-view";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offer-grid-view/vlocity-dc-offer-grid-view";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-filter/vlocity-dc-filter";

let productListTemplate = function prepareTemplate(offersListComponent) {
  let offerList = offersListComponent.offers;
  let items = offersListComponent.viewIcons;
  let template = html`
    <link
      type="text/css"
      rel="stylesheet"
      href="${offersListComponent.ndsLibPath}"
    />
    <div class="nds-dc-offerlist-container">
      <slot name="dc-offer-list-toggle-view">
        <div class="nds-dc-filter-wrapper">
          ${items.map(
            (i, index) =>
              html`
                <span @click=${e => offersListComponent.onSelectView(e, index)}>
                  ${index == offersListComponent.activeIndex
                    ? html`
                        ${i.img2}
                      `
                    : html`
                        ${i.img1}
                      `}
                </span>
              `
          )}
          <div>
            <vlocity-dc-filter
              .filterData="${offersListComponent.filterData}"
            ></vlocity-dc-filter>
          </div>
        </div>
      </slot>

      ${offerList.length === 0 && !offersListComponent.loading
        ? html`
            <div class="nds-dc-no-data">
              <slot name="dc-not-found">
                ${offersListComponent.digitalCommerceTranslation.translate(
                  "DCNoOffers"
                )}
              </slot>
            </div>
          `
        : ``}
      ${offerList.length > 0
        ? offersListComponent.state === 1
          ? html`
              <p>${offersListComponent.offersShowing} offers showing</p>
              <reference-grid-view
                .offers="${offerList}"
              ></reference-grid-view>
            `
          : html`
              <vlocity-dc-offer-list-view
                .offers="${offerList}"
              ></vlocity-dc-offer-list-view>
            `
        : ""}
      ${offersListComponent.nextOffersActionAvailable && offerList.length > 0
        ? html`
            <div class="nds-dc-load-more">
              <slot name="dc-load-more-btn">
                <button
                  class="nds-button nds-button_brand"
                  @click=${e => {
                    offersListComponent.fetchOffers(
                      offersListComponent.catalogCode
                    );
                  }}
                >
                  ${offersListComponent.digitalCommerceTranslation.translate(
                    "CPQLoadMore"
                  )}
                </button>
              </slot>
            </div>
          `
        : ""}
      ${offersListComponent.loading
        ? html`
            <div class="nds-spinner_container">
              <div
                class="nds-spinner_brand nds-spinner"
                aria-hidden="false"
                role="alert"
              >
                <svg
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 100 100"
                >
                  <circle cx="6" cy="50">
                    <animateTransform
                      attributeName="transform"
                      dur="1s"
                      type="translate"
                      values="0 15 ; 0 -15; 0 15"
                      repeatCount="indefinite"
                      begin="0.1"
                    />
                  </circle>
                  <circle cy="50">
                    <animateTransform
                      attributeName="transform"
                      dur="1s"
                      type="translate"
                      values="0 10 ; 0 -10; 0 10"
                      repeatCount="indefinite"
                      begin="0.2"
                    />
                  </circle>
                  <circle cy="50">
                    <animateTransform
                      attributeName="transform"
                      dur="1s"
                      type="translate"
                      values="0 5 ; 0 -5; 0 5"
                      repeatCount="indefinite"
                      begin="0.3"
                    />
                  </circle>
                </svg>
              </div>
            </div>
            <slot name="dc-loading-message"></slot>
          `
        : ""}
    </div>
  `;
  return template;
};

export default productListTemplate;
