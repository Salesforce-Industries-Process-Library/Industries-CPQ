import { LitElement, html } from "lit-element";
import VlocityDCProductList from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-offers-list/vlocity-dc-offers-list.js";
import { digitalCommerceSDKInstance } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils.js";
import referenceProductListTemplate from "./reference-product-list-template.js";

export class ReferenceProductList extends VlocityDCProductList {
    constructor() {
      super(); // always call super() first in the ctor.
      this.template = referenceProductListTemplate;
      this.offersShowing = 0;
    }
    render() {
      return this.template(this);
    }
    fetchOffersGetInput(catalogCode) {
      return Object.assign(this.digitalCommerceSDK.createGetOffersInput(), {
        catalogCode: catalogCode,
        offset: this.offers.length,
        pageSize: 3
      });
    }
    fetchOffersPostHook(response) {
      this.offersShowing = response.offers.length;
    }
}

customElements.define("reference-product-list", ReferenceProductList);