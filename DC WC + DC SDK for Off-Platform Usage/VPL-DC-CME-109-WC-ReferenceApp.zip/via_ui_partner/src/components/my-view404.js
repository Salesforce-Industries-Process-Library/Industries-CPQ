import { html, render } from "lit-html";

// These are the shared styles needed by this element.
import { SharedStyles } from './shared-styles.js';

class MyView404 extends HTMLElement {
  constructor() {
    super();
    this.render();
  }
  template(scope) {
    let dataTableTemplate =  html`
      ${SharedStyles}
      <section>
        <h2>Oops! You hit a 404</h2>
        <p>The page you're looking for doesn't seem to exist. Head back
           <a href="/">home</a> and try again?
        </p>
      </section>
    `;
    return dataTableTemplate;
  }
  render() {
    this.template && render(this.template(this), this);
  }
}

window.customElements.define('my-view404', MyView404);
