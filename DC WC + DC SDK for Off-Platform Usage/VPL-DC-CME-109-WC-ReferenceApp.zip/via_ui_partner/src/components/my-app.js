import { LitElement, html } from 'lit-element';
import { setPassiveTouchGestures } from '@polymer/polymer/lib/utils/settings.js';
import { connect } from 'pwa-helpers/connect-mixin.js';
import { installMediaQueryWatcher } from 'pwa-helpers/media-query.js';
import { installOfflineWatcher } from 'pwa-helpers/network.js';
import { installRouter } from 'pwa-helpers/router.js';
import { updateMetadata } from 'pwa-helpers/metadata.js';
import { digitalCommerceSDKInstance } from '@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-sdk-utils';
import { DCCustomLabels } from "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-utils/vlocity-dc-custom-labels";
import "@vlocity-cme-wc/digitalcommerce-components-src/vlocity-dc-global-header/vlocity-dc-global-header.js";




// This element is connected to the Redux store.
import { store } from '../store.js';

// These are the actions needed by this element.
import {
  navigate,
  updateOffline,
  updateDrawerState
} from '../actions/app.js';

// These are the elements needed by this element.
import '@polymer/app-layout/app-drawer/app-drawer.js';
import '@polymer/app-layout/app-header/app-header.js';
import '@polymer/app-layout/app-scroll-effects/effects/waterfall.js';
import '@polymer/app-layout/app-toolbar/app-toolbar.js';
import './snack-bar.js';

class MyApp extends connect(store)(LitElement) {
  render() {
    // Anything that's related to rendering should be done in here.
    return html`
    <style>
      app-header {
        --app-drawer-width: 300px;
        display: block;

        --app-primary-color: #E91E63;
        --app-secondary-color: #293237;
        --app-dark-text-color: var(--app-secondary-color);
        --app-light-text-color: white;
        --app-section-even-color: #f7f7f7;
        --app-section-odd-color: white;

        --app-header-background-color: #003a5c;
        --app-header-text-color: var(--app-dark-text-color);
        --app-header-selected-color: var(--app-primary-color);

        --app-drawer-background-color: var(--app-secondary-color);
        --app-drawer-text-color: #858788;
        --app-drawer-selected-color: #78909C;
        --app-font-family: Futura;
        --app-header-toolbar-color:#fff;
        --app-header-content-color:#fff;

        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        text-align: center;
        background-color: var(--app-header-background-color);
        color: var(--app-header-text-color);
        border-bottom: 1px solid #eee;
        box-shadow: 0 -4px 12px 0 rgba(0,0,0,.6);
      }
      app-drawer {
        z-index: 9999;
      }

      .toolbar-top {
        background-color: var(--app-header-background-color);
        
      }

      [main-title] {
        /*text-transform: lowercase;*/
        font-size: 20px;
        /* In the narrow layout, the toolbar is offset by the width of the
        drawer button, and the text looks not centered. Add a padding to
        match that button */
        /*padding-right: 44px;*/
        color:var(--app-header-content-color);
        margin-right: 15px;
      }


      .toolbar-list > a {
        display: inline-block;
        color: var(--app-header-text-color);
        text-decoration: none;
        line-height: 30px;
        padding: 4px 24px;
      }

      .toolbar-list > a[selected] {
        color: var(--app-header-selected-color);
        border-bottom: 4px solid var(--app-header-selected-color);
      }

      .menu-btn {
        background: none;
        border: none;
        fill: var(--app-header-toolbar-color);
        cursor: pointer;
        height: 44px;
      }
      .lock-icon{
        fill:var(--app-header-content-color);
        display:flex;
      }

      .drawer-list {
        box-sizing: border-box;
        width: 100%;
        height: 100%;
        padding: 24px;
        background: var(--app-drawer-background-color);
        position: relative;
      }

      .drawer-list > div >a {
        display: block;
        text-decoration: none;
        color: var(--app-drawer-text-color);
        line-height: 40px;
        padding: 0 24px;
      }
      .drawer-list > svg {
        margin-top: 45px;
        margin-left: 20px;
      }

      .drawer-list > a[selected] {
        color: var(--app-drawer-selected-color);
      }
      .reference-drawer-style {
        border-bottom: 1px solid #e6eaeb;
        border-top: 1px solid #e6eaeb;
        list-style-type: none;
        padding: 0px;
        height: 100%;
        background-color:#ffff;
      }
      .reference-drawer{
        overflow: scroll;
        max-height: 100%;
      }
      .reference-logo-holder{
        height: 150px;
        background-color: var(--app-header-background-color);
      }
      .reference-logo{
        position: relative;
        top: 50%;
        width: 80%;
        left: 4%;
      }
      .reference-menu-logo{
        margin-top: 50px;
        margin-left: 20px;
      }
      .reference-login{
        margin-top: 20px;
        margin-left: 20px;
        color: white;
        display:none;
      }
      iframe{
        border: 0px;
      }
      iframe.dc-payment_iframe{
        display:none;
        margin-left: 20%;
        margin-top: -60px;
      }
      .reference-line-color{
        border:1px solid #f0f4f5
      }
      /* Workaround for IE11 displaying <main> as inline */
      main {
        display: block;
      }

      .main-content {
        min-height: 100vh;
        background-color: #F3F4F8;
        overflow: auto;
      }

      .page {
        display: none;
      }

      .page[active] {
        display: block;
      }

      footer {
        display: none;
        padding: 24px;
        background: var(--app-drawer-background-color);
        color: var(--app-drawer-text-color);
        text-align: center;
      }

      /* Wide layout: when the viewport width is bigger than 460px, layout
      changes to a wide layout. */
      @media (min-width: 460px) {
        .toolbar-list {
          display: block;
        }

        

        /* The drawer button isn't shown in the wide layout, so we don't
        need to offset the title */
        [main-title] {
          padding-right: 0px;
        }
      }
    </style>

    <!-- Drawer content -->
    <app-drawer .opened="${this._drawerOpened}"
        @opened-changed="${this._drawerOpenedChanged}">
      <nav class="drawer-list reference-drawer-style">
      <div class="reference-logo-holder">
      <img class="reference-logo" src="../../images/vlocity-logo-horizontal-notag.svg" alt="Vlocity">
        <div class="reference-login" href="/">Login</div>
        </div>
        <div class="reference-drawer">
        <hr class="reference-line-color" style="margin-top:50px;">
        <a ?selected="${this._page === 'home'}" href="/">Shop</a>
        <a ?selected="${this._page === 'view2'}" href="/">Roaming</a>
        <a ?selected="${this._page === 'view3'}" href="/">Data</a>
        <hr class="reference-line-color">
        <a ?selected="${this._page === 'view4'}" href="/">Cart</a>
        <a ?selected="${this._page === 'checkout'}" href="checkout">Checkout</a>
        <hr class="reference-line-color" style="margin-top:15px;margin-bottom:30px;">
        <a ?selected="${this._page === 'view5'}" href="/">Activate SIM card</a>
        <hr class="reference-line-color" style="margin-top:40px;">
        <a ?selected="${this._page === 'view5'}" href="/">Settings</a>
        <a ?selected="${this._page === 'view5'}" href="/">FAQ</a>
        <hr class="reference-line-color" style="margin-top:20px;">
        </div>
      </nav>
    </app-drawer>

    <!-- Main content -->
    <main role="main" class="main-content">
        ${this._page !== "" && !this._page.match(/^checkOut*/) 
        ? html`<vlocity-dc-global-header .authConfiguration="${this.firebaseConfig}"></vlocity-dc-global-header>` : ''}
        ${this._page === "home" || this._page === ""
        ? html`  
          <reference-home-page name="home" 
            class="page active" 
            parentCatalogCode="${this.parentCatalogCode}" 
            catalogCode="${this.catalogCode}" active>
          </reference-home-page>`
        : html``}
        ${this._page !== "" && this._page.match(/^config*/)
        ? html`
          <reference-selection-page name="config" 
            productUrl="${this.getProductUrl(this._page)}" 
            catalogCode="${this.catalogCode}"
            offerCode="${this.offerCode}"
            urlParams="${this.urlAttributes}"
            class="page active"
            active>
          </reference-selection-page>
        `
        : html``}
        ${this._page !== "" && this._page.match(/^addons*/)
        ? html`
            <reference-offer-addons
              name="addons"
              class="active"
              catalogCode="${this.catalogCode}"
              offerCode="${this.offerCode}"
              .promoList="${this.promoList}"
              active
            ></reference-offer-addons>
          `
        : html``}
        ${this._page !== "" && this._page.match(/^shoppingcart*/)
        ? html`
          <reference-shopping-cart name="shoppingcart" 
            class="page active"
            isAsset="${this.isAsset}"
            isLoggedIn="${this.isLoggedIn}"
            catalogCode="${this.catalogCode}"
            cartContextKey="${this.cartContextKey}"
            .cartResponse="${this.cartResponse}"
            active>
          </reference-shopping-cart>
        `
        : html``}
        ${this._page !== "" && this._page.match(/^account*/) &&
        html`
          <reference-my-account></reference-my-account>
        `}
        ${this._page !== "" && this._page.match(/^checkOut*/)
        ? html`
        <reference-checkout class="active"
              isLoggedIn="${this.isLoggedIn}"
              dueToday=${this.dueToday}
              dueMonthly=${this.dueMonthly}
              catalogCode=${this.catalogCode}
              cartContextKey="${this.cartContextKey}"
              checkoutPaymentUrl=${this.checkoutPaymentUrl}
              .userInfo="${this.userInfo}"
              orderId=${this.orderId}
              .authConfiguration="${this.firebaseConfig}"
            ></reference-checkout>
            <iframe
              id="paymentIframe"
              class="dc-payment_iframe"
              src=""
              seamless
              width="60%"
              height="400px"
              seamless="seamless"
            ></iframe>
        `
        : html``}
        <my-view404 class="page" ?active="${this._page === 'view404'}"></my-view404>
    </main>

    <footer>
      <p>© 2019 Vlocity Inc. </p>
    </footer>

    <snack-bar ?active="${this._snackbarOpened}">
        You are now ${this._offline ? 'offline' : 'online'}.</snack-bar>
    `;
  }

  static get properties() {
    return {
      appTitle: { type: String },
      _page: { type: String },
      _drawerOpened: { type: Boolean },
      _snackbarOpened: { type: Boolean },
      _offline: { type: Boolean },
      parentCatalogCode: String,
      catalogCode: String,
      offerCode: String,
      isLoggedIn: Boolean,
      isAsset: Boolean,
      cartContextKey: String,
      userInfo: String,
      cartResponse: Object
    }
  }

  /* currently disabled the shadow dom for sake of checkout page. Braintree not working properly with shadow dom enabled */
  createRenderRoot() {
    return this;
  }

  constructor() {
    super();
    // To force all event listeners for gestures to be passive.
    // See https://www.polymer-project.org/3.0/docs/devguide/settings#setting-passive-touch-gestures
    this.parentCatalogCode = "";
    this.catalogCode = "";
    this.digitalCommerceSDK = digitalCommerceSDKInstance().digitalCommerce;
    this.digitalCommerceTranslation = digitalCommerceSDKInstance().digitalCommerceTranslation;
    this.language = digitalCommerceSDKInstance().digitalCommerce.language
      ? digitalCommerceSDKInstance().digitalCommerce.language
      : "en_US";
    setPassiveTouchGestures(true);
    this.checkoutPaymentUrl = document
    .querySelector("[name=vlocity-dc-payment-url][value]")
    .getAttribute("value");
    this.digitalCommerceSDK.register("vlocity-dc-seo-meta-data-updated", {
      result: this.seoMetaDataUpdated.bind(this)
    });
    this.userInfo = sessionStorage.getItem("userInfo") || {};
    this.orderId = "";
    this.isLoggedIn = sessionStorage.getItem("isLoggedIn") || false;
    this.isAsset = false;
    this.cartResponse = null;
    this.cartContextKey = sessionStorage.getItem("cartContextKey") || "";
    this.firebaseConfig = {
      apiKey: "YOUR API KEY HERE",
      authDomain: "YOUR AUTH DOMAIN HERE",
      databaseURL: "YOUR DB URL HERE",
      projectId: "PROJECT ID",
      storageBucket: "STORAGE BUCKET",
      messagingSenderId: "SENDER ID",
      appId: "APP ID",
      measurementId: "MEASUREMENT ID"
    };
  }

  getProductUrl(path) {
    path = path.slice(1);
    let tempUrl = path.split("/");
    tempUrl.shift();
    return tempUrl.join("/");
  }

  firstUpdated() {
    installRouter((location) => store.dispatch(navigate(decodeURIComponent(location.pathname))));
    installOfflineWatcher((offline) => store.dispatch(updateOffline(offline)));
    installMediaQueryWatcher(`(min-width: 460px)`,
        () => store.dispatch(updateDrawerState(false)));
  }

  updated(changedProps) {
    if (changedProps.has('_page')) {
      const pageTitle = this.appTitle + ' - ' + this._page;
      updateMetadata({
        title: pageTitle,
        description: pageTitle
        // This object also takes an image property, that points to an img src.
      });
    }
  }

  seoMetaDataUpdated(seoMetaData) {
    const pageTitle = this.appTitle + ' - ' + seoMetaData.pageTitle;
    updateMetadata({
      title: pageTitle,
      description: seoMetaData.description,
      keyWords: seoMetaData.keyWords
      // This object also takes an image property, that points to an img src.
    });
    var metaTags = document.getElementsByTagName("META");
    metaTags.keywords.content = seoMetaData.keyWords;
  }

  _menuButtonClicked() {
    store.dispatch(updateDrawerState(true));
  }

  _drawerOpenedChanged(e) {
    store.dispatch(updateDrawerState(e.target.opened));
  }

  stateChanged(state) {
    this._page = state.app.page;
    this._offline = state.app.offline;
    this._snackbarOpened = state.app.snackbarOpened;
    this._drawerOpened = state.app.drawerOpened;
  }
  connectedCallback() {
    super.connectedCallback();
    this.getLabels(DCCustomLabels, this.language);
    if (this.digitalCommerceSDK) {
      this.customNavigationEventHandler = {
        result: this.customNavigation.bind(this)
      };
      this.digitalCommerceSDK.register(
        "vlocity-dc-route-navigation",
        this.customNavigationEventHandler
      );
      this.digitalCommerceSDK.register("vlocity-dc-update-catalog-code", {
        result: this.updateCatalogCode.bind(this)
      });
    }
  }
  navigate(path) {
    if (path === "/") {
      this._page = "home";
    } else {
      this._page = path.slice(1);
    }
    this.setAttributes(this._page);
    this.render();
  }

  customNavigation(routeData) {
    window.history.pushState({}, "", routeData.defaultRouteUrl);
    if (routeData.data && routeData.data.promoList) {
      this.promoList = routeData.data.promoList;
    }
    if (routeData.data && routeData.data.paymentInfo) {
      this.dueToday = routeData.data.paymentInfo.dueToday;
      this.dueMonthly = routeData.data.paymentInfo.dueMonthly;
    }
    if (routeData.data && routeData.data.userInfo) {
      this.userInfo = routeData.data.userInfo;
    }
    if (routeData.data && routeData.data.orderId) {
      this.orderId = routeData.data.orderId;
    }
    if (routeData.data && routeData.data.catalogCode) {
      this.catalogCode = routeData.data.catalogCode;
    }
    if (routeData.data && routeData.data.cartResponse) {
      this.cartResponse = routeData.data.cartResponse;
    }
    if (routeData.source === "assets") {
      this.isAsset = true;
    }
    this.navigate(routeData.defaultRouteUrl);
  }
  setAttributes(path) {
    if (path) {
      const pathArr = this.getParamsFromUrl(path);
      if (pathArr.length >= 3) {
        this.catalogCode = pathArr[1];
        if (pathArr[0] !== "shoppingcart") {
          this.offerCode = pathArr[2];
        } else {
          this.cartContextKey = pathArr[2];
        }
        if (pathArr.length === 4) {
          this.urlAttributes = pathArr[3];
        }
      }
    }
  }

  getParamsFromUrl(path) {
    return path.split("/");
  }

  updateCatalogCode(data) {
    if (data.parentCatalogCode) {
      this.parentCatalogCode = data.parentCatalogCode;
    } else if (data.catalogCode) {
      this.catalogCode = data.catalogCode;
    }
  }
  getLabels(labelList, language) {
    const translationSDK = digitalCommerceSDKInstance().digitalCommerceTranslation;
    const fetchTranslationsInput = translationSDK.createFetchTranslationsInput();
    fetchTranslationsInput.textToTranslate = labelList;
    fetchTranslationsInput.language = language;
    return translationSDK.fetchTranslations(fetchTranslationsInput);
  }
}

window.customElements.define('my-app', MyApp);
