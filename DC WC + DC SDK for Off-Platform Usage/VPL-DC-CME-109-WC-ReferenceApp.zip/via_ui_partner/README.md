# Vlocity UI Partner
Brief description about Vlocity UI Partner.

[![Built with pwa–starter–kit](https://img.shields.io/badge/built_with-pwa–starter–kit_-blue.svg)](https://github.com/Polymer/pwa-starter-kit "Built with pwa–starter–kit")


# PWA Starter Kit

This sample app is a starting point for building PWAs. Out of the box, the template
gives you the following features:
- all the PWA goodness (manifest, service worker)
- a responsive layout
- application theming
- example of using Redux for state management
- offline UI
- simple routing solution
- fast time-to-interactive and first-paint through the PRPL pattern
- easy deployment to prpl-server or static hosting
- unit and integrating testing starting points
- documentation about other advanced patterns.

### 📖 Head over to the [documentation site](https://pwa-starter-kit.polymer-project.org/) for more details or check out [how to get started](https://pwa-starter-kit.polymer-project.org/setup/)!


## Installation
To install the project’s dependencies, run
```npm install```

## Reload Vlocity SDK Dependencies
Delete @node_modules folder
```rm -r node_modules```

Clean npm cache
```npm cache clean --force```

Reload Vlocity SDK from NPM registry
```npm install```

## Run the app locally
```npm start```

his will start a local server on port 8081. Open http://localhost:8081 to view your app in the browser. Note that this server can continue running as you’re making changes to your application, which you will see if you refresh the browser tab.

If the port is already taken on your computer, you can configure them using command line argument:

```npm start -- --port 5000```


## Run the tests
Check out the [Application testing](https://pwa-starter-kit.polymer-project.org/application-testing) page for more information about the tests. For a quick way to run the tests, run

```npm run test```